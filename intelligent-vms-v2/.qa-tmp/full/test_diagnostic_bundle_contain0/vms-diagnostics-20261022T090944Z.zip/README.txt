Intelligent VMS diagnostic bundle
=================================

Contains: version, redacted configuration, platform facts, dependency
versions, database counts, camera inventory (no credentials), recent
events and alarms, storage diagnostics and redacted log tails.

Deliberately excluded: the master encryption key, camera passwords,
API keys, tokens, SMTP/OIDC secrets, recorded video and snapshots.
