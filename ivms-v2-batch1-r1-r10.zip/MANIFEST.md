# Change manifest — Batch 1 R1–R10

Baseline: `83e965d9c0445b842d84b384fc89441cb54502bf` (62 files, all SHA-256 verified on reconstruction).
Deleted files: none. Root workflow `.github/workflows/intelligent-vms-v2-ci.yml`: **unchanged**.

| Status | Path | Baseline SHA-256 | New SHA-256 |
|---|---|---|---|
| ADDED | `intelligent-vms-v2/database/migrations/0002_media_connections.py` | `—` | `05c0f96dbb799b30f22c30e8ba36850152d3148309e734e0a409fdd68cf7ef32` |
| MODIFIED | `intelligent-vms-v2/deploy/docker/.env.example` | `b0adc2bf0addae746cf481f6ae10a09f729ba8a44ee9138b0263d07435cb46c8` | `60aa89e5ca1876aad2934d27a077a70510e0582c8e8138b8106d660c3ff7e744` |
| MODIFIED | `intelligent-vms-v2/deploy/docker/docker-compose.yml` | `c0230eae577961aef106794b39270affd045420f0d9ca9eabdde668fd4f0882c` | `2f68596d9253156eb906cb4e6cbd6ab7462e8c90528acd99e5d1d16b49144ace` |
| MODIFIED | `intelligent-vms-v2/deploy/docker/mediamtx.yml` | `75f95575e8644bceb177e4e8a57a1a5119f5dd365e3613ec404bfccbd0289291` | `ec5958d48242fe6562a9cbde8fc194b4643a24893c1c9502f5cb25619e74049e` |
| MODIFIED | `intelligent-vms-v2/docs/LIMITATIONS.md` | `a0b5bba4ae7ad1efe84bf5f056e352ad2d72ec3cb2ab7c432b19e09440966bd5` | `2c589209069dfa6433fbe134415da1aae2dd7242b3c2de137c324f667da8bd3b` |
| ADDED | `intelligent-vms-v2/docs/decisions/ADR-0012-media-gateway-authorization.md` | `—` | `6a4cb07b3d61594f5b805bdecd24f5a905f8216d7e3739f2f573c934867849f7` |
| ADDED | `intelligent-vms-v2/docs/verification/batch1-mutation-checks.txt` | `—` | `f98fdd72e76f8effeb7f70c92e3e7112dba9c73ae9333319b3b5b08707cf0165` |
| ADDED | `intelligent-vms-v2/docs/verification/batch1-postgres-migration.txt` | `—` | `581076892cf1a62e84f309dcbe6861b228f4fd74115cc95e82652daeb99917df` |
| ADDED | `intelligent-vms-v2/docs/verification/batch1-test-run.txt` | `—` | `a292c14cc25061df1865d8bb964e46be7945d158beb0609f6db4b922435a68d8` |
| MODIFIED | `intelligent-vms-v2/pytest.ini` | `734003114598b5b83140d50802efdf861871e03672cd5356efedf532f2589913` | `6d6a45de0ebd462d51ca3846bbaddedecc40b666173667c5d13a9b9444c1a449` |
| ADDED | `intelligent-vms-v2/services/control-api/app/api/internal/__init__.py` | `—` | `4b14a168006f06c43ecffa6e03143df4db4e081a673354687c506f05780f1cd8` |
| ADDED | `intelligent-vms-v2/services/control-api/app/api/internal/media_auth.py` | `—` | `661cd625e89e8f3283d0e2a0781fff28eadcecc19cf23022250d2cf3c0a2ecc7` |
| MODIFIED | `intelligent-vms-v2/services/control-api/app/config.py` | `c7708ca0ecdf7e08621c590a89da708d11bd75fa4eaf7fa2558fcd7d3ce07349` | `0e8a64c36db7d063810cac5d471ded27707f8de50df8a9ed6fa5564a59a69f66` |
| MODIFIED | `intelligent-vms-v2/services/control-api/app/db/models.py` | `62f5bdaf1a274712a2da02d54eb40e2df9086ae55d4bc991b5f607478df87a0e` | `3bcaefe83e14ade8f33b3d9092204797d2d364e4dab2e7b6c4af630906200a42` |
| MODIFIED | `intelligent-vms-v2/services/control-api/app/lifecycle.py` | `3851aa1da544aa8de35d80a6abcf8a75c9720da4797fcc3d9ce9929ad17d3254` | `e805f51d39acc7081f5d8b22ae695996195eb1470da37784620255178bd6f8a9` |
| MODIFIED | `intelligent-vms-v2/services/control-api/app/main.py` | `861310ee2e747a33045809a2c82f76d5ae3e10a9db784c5113a0788554eb0f75` | `6265fd3411b8b62318bad8d1e4f5586546179d89aa550a596b9cc02797e5774e` |
| ADDED | `intelligent-vms-v2/services/control-api/app/media/connection_registry.py` | `—` | `5dffc09ff9b9c8f552551590834499ce9a268eed7a56ceec663cdc8cc34b1ac3` |
| ADDED | `intelligent-vms-v2/services/control-api/app/media/media_auth.py` | `—` | `63210ddfa90f350b620ab9c8b20051fc9eb4c270a954fbe9e200b31b86b3e9cb` |
| MODIFIED | `intelligent-vms-v2/services/control-api/app/media/mediamtx_client.py` | `9abf1a64a97bb8ea1847f7f089e80c7d2c3acd3dfbde0e40f34ffe2412716f23` | `465cacf30a36f3b023d9092dfe079c7f9d9260527362b73aca77f738319095dc` |
| MODIFIED | `intelligent-vms-v2/services/control-api/app/media/session_broker.py` | `3e4453519c391cffbd204cc26891c07d7e5983123f967b374b8654246773090f` | `7a88e846807c05bf2d9c31b159e06f53d86214a6335a8679fd4aa0a5256a5240` |
| MODIFIED | `intelligent-vms-v2/services/control-api/app/version.py` | `5f4a4dcac4af9223e5d48aa7da9d7af1741c41d32091646d710c80b581c860d5` | `565f70285997457eb1052076f3e11c0e95014a6b3b35938fbf48b80160fc336d` |
| MODIFIED | `intelligent-vms-v2/services/control-api/pyproject.toml` | `7768e6ce325730213ded5da5aaed6f97a87442d55e6a08af0cbbfd836567ef40` | `954f53846e919f1716206a91d23bd4d027d41fc3b9a22fa6021d315534ec7489` |
| ADDED | `intelligent-vms-v2/tests/gateway/test_mediamtx_gateway.py` | `—` | `bf388a603393888d820bfb23c8c1d8d4e5a70f32bcd99528f8d210b7b5f07e25` |
| ADDED | `intelligent-vms-v2/tests/unit/test_deploy_config.py` | `—` | `92f47a2c61a325554a83e0163f8d7f53845af7599fae02942fa42b5b097578f7` |
| ADDED | `intelligent-vms-v2/tests/unit/test_media_gateway_admission.py` | `—` | `58fae6ecf6401f2fa100aec6741f09d44ac1a5243b8d874a07d254f4d81e2fdf` |
| ADDED | `intelligent-vms-v2/tools/resolve_mediamtx_digest.sh` | `—` | `4e7801230af4e3c8ef73f49b0091003d17775f2887a1b5ca859c3dbaaeb9943d` |

## Artifact checksums

```
8301877c59f23f4f860beb552b82c57a1181bc0a027e2af433519321580989a6  batch1-r1-r10.patch
5c7dec6c00540207fc78f3e8cb7a69c168dfe9fb1393889668addba3d03abacc  CORRECTION-REPORT.md
1f2b67fa69b51c3ecda9e294416f42cfe57cc0c2c17084ba8c07d6c0e30de729  batch1-junit.xml
```

The ZIP checksum is in `SHA256SUMS.txt`, outside the ZIP.
